package com.cg.controller;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entities.Customer;
import com.cg.service.CustomerService;

@RestController
public class CustomerController {

	@Autowired
	private CustomerService service;

	@GetMapping(path = "/customer/{id}", produces = "application/json")
	public ResponseEntity<Customer> getCustomerById(@PathVariable int id) { // @RequestParam("id") int id) {
		try {
			Customer cust = service.getCustomerById(id);
			return new ResponseEntity<Customer>(cust, HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity("Customer id not found", HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping(path = "/customername/{name}")
	public ResponseEntity<Customer> getCustomerByName(@PathVariable String name) {
		try {
			Customer customer = service.findByCustomerName(name);
			return new ResponseEntity<Customer>(customer, HttpStatus.OK);
		} catch (NoSuchElementException E) {
			return new ResponseEntity("Customer name not found", HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping(path = "/customer/all")
	public Iterable<Customer> getAllCustomers() {
		return service.getAllCustomers();
	}

	@PostMapping(path = "/addcustomer", consumes = "application/json")
	public Customer insertCustomer(@RequestBody Customer customer) {
		return service.saveCustomer(customer);
	}

	@DeleteMapping("/delete/{id}")
	public String deleteCustomer(@PathVariable int id) { // @RequestParam("id") int id) {
		
			return service.delete(id);
		
	}

	@PutMapping("/update/{id}")
	public Customer updateCustomer(@PathVariable int id, @RequestBody Customer customer) {
		return service.updateCustomer(customer, id);
	}

}
