package com.cg.repo;
import org.springframework.data.repository.CrudRepository;

import com.cg.entities.Customer;

public interface CustomerRepo extends CrudRepository<Customer, Integer> {

	Customer findByCustomerName(String name);
}
