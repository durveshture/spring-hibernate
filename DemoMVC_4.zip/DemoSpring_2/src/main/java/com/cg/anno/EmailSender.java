package com.cg.anno;

import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Component("mail")
@Lazy
public class EmailSender implements Sender {

	public EmailSender() {
		System.out.println("Email Sender is ready");
	}

	public void send(String to, String msg) {

		System.out.println("Email" + msg + " sent to " + to);
	}

}
