package com.cg.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.anno.Hello;

//import com.cg.ioc.Hello;

public class TestHello {

	ApplicationContext ac;
	
	@Before
	public void init() {
//		 ac= new ClassPathXmlApplicationContext("hello.xml");	
		 ac= new ClassPathXmlApplicationContext("annotated.xml");
	}
	
	@Test
	public void testGetObject() {
		Hello h= (Hello) ac.getBean("helloObj1");
		System.out.println(h.getGreeting());
		System.out.println(h.getNumber());
		assertNotNull("Null obj", h);
	}
	
}
