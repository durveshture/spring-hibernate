package com.cg.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.anno.Producer;

//import com.cg.ioc.Producer;

public class TestSender {

	@Test
	public void testProcess() {
		// this line initializes all bean class objects- EAGER loader
//		ApplicationContext ctx= new ClassPathXmlApplicationContext("senderConfig.xml");
		ApplicationContext ctx= new ClassPathXmlApplicationContext("annotated.xml");
//		System.out.println("a");
		Producer producer= (Producer) ctx.getBean("producer");
		
		producer.process("sms", "8452802158", "hello");
		producer.process("mail", "durvesh@gmail.com", "hi");
		producer.process("whatsapp", "7977918168", "call back");
	}
}
