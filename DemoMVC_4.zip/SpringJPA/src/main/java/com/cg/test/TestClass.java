package com.cg.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.entity.Product;
import com.cg.repo.ProductRepo;


public class TestClass {

	public static void main(String[] args) {
		
		Product p1 = new Product("Book", 200);
		 Product p2 = new Product("Deo", 195);
		 Product p3 = new Product("DVD", 100);
		 
		 ApplicationContext context = new ClassPathXmlApplicationContext("appCtx.xml");
			ProductRepo repo= (ProductRepo) context.getBean("repo");
		 
		 repo.saveProduct(p1);
		 repo.saveProduct(p2);
		 repo.saveProduct(p3);
		 
		 System.out.println(repo.getProduct(201));
		 
		 System.out.println(repo.getAllProducts());

	}
}
