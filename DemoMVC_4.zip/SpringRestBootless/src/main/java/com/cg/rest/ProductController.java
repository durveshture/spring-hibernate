package com.cg.rest;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Product;
import com.cg.repo.ProductRepo;

@RestController
public class ProductController {

	ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
	ProductRepo repo = (ProductRepo) ctx.getBean("repo");
	
	
	@GetMapping("/hello")
	public Product get(Product product) {
		repo.get(63);
		return product;
	}
	
	@PutMapping("/product")
	public Product create(Product product) {
		return product;
	}
}
