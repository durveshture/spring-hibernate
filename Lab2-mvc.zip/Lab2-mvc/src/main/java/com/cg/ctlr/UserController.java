package com.cg.ctlr;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.entity.Login;
import com.cg.entity.Trainee;
import com.cg.service.TraineeService;

@Scope("session")
@Controller
public class UserController {

	// @Autowired TraineeService service;// will inject dao from XML file

	ArrayList<String> domainList;
	ArrayList<String> locationList;

	@RequestMapping("/")
	public String homePage(Model model) {
		model.addAttribute("login", new Login());
		return "login";
	}

	@RequestMapping("/checkLogin")
	public String checkLogin(Login login, Model m) {
		String invalid = "Enter correct Details";
		m.addAttribute("invalid", invalid); // Logic to validate userName and password against database

		return "trainee";

	}

	@RequestMapping("/addTrainee")
	public String addtrainee(Model model) {
		locationList = new ArrayList<String>();

		locationList.add("Chennai");
		locationList.add("Bangalore");
		locationList.add("Pune");
		locationList.add("Mumbai");

		domainList = new ArrayList<String>();

		domainList.add("Java");
		domainList.add("Struts");
		domainList.add("Spring");
		domainList.add("Hibernate");

		model.addAttribute("domainList", domainList);
		model.addAttribute("locationList", locationList);

		model.addAttribute("trainee", new Trainee());

		return "addTrainee";

	}

	@RequestMapping("/deleteTrainee")
	public String deleteTrainee(Model model) {
		model.addAttribute("trainee", new Trainee());
		return "deleteTrainee";

	}

	@RequestMapping("/modifyTrainee")
	public String modifyTrainee(Model model) {
		model.addAttribute("trainee", new Trainee());
		return "modifyTrainee";

	}

	@RequestMapping("/retrieveTrainee")
	public String retrieveTrainee(Model model) {
		model.addAttribute("trainee", new Trainee());
		return "retrieveTrainee";

	}

	@RequestMapping("/retrieveAllTrainee")
	public String retrieveAllTrainee(Model m) {
		List<Trainee> list = null;
		m.addAttribute("list", list);
		return "retrieveAllTrainee";

	}

	@Autowired
	private TraineeService service;

	/*
	 * It saves object into database. The @ModelAttribute puts request data into
	 * model object. You need to mention RequestMethod.POST method because default
	 * request is GET
	 */

	@RequestMapping(path = "add")
	public String save(@ModelAttribute("trainee") Trainee t, Model model) {

		service.addTrainee(t);
		model.addAttribute("login", new Login());
		return "trainee";
		// will redirect to trainee request mapping
	}

	/*@GetMapping
	public Iterable findAll() {
		return service.retrieveAll();
	}*/

	// It provides list of employees in model object

	/*
	 * @RequestMapping("/viewemp") public String viewemp(Model m) { List<Trainee>
	 * list = (List<Trainee>) service.retrieveAll(); m.addAttribute("list", list);
	 * return "redirect:/checkLogin"; } }
	 */

}