package com.cg.bean;

import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Component;

//@Component("customer")
public class Customer {

	// Customer details
	private String name;
	private String email;
	private double balance;
	private long mobileNo;
	private double custId;
	private String password;

	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public String getPassword() {
		return password;
	}

	public Customer(String name, String email, double balance, long mobileNo,
			double custId, String password) {
		super();
		this.name = name;
		this.email = email;
		this.balance = balance;
		this.mobileNo = mobileNo;
		this.custId = custId;
		this.password = password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	// getters and setters
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public double getCustId() {
		return custId;
	}

	public void setCustId(double custId) {
		this.custId = custId;
	}

	// ovverriding toString() of object class
	@Override
	public String toString() {
		return "Customer [name=" + name + ", email=" + email + ", balance="
				+ balance + ", mobileNo=" + mobileNo + ", custId=" + custId
				+ ", password=" + password + "]";
	}
}
