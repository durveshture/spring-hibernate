package com.cg.dao;

import com.cg.ExceptionClass.LowBalanceException;
import com.cg.ExceptionClass.NegativeAmountException;
import com.cg.ExceptionClass.SenderReceiverSameException;
import com.cg.bean.Customer;

public interface InterfaceDao {

	String deposit(Customer customer, double amount) throws NegativeAmountException;

	String withdraw(Customer customer, double amount) throws LowBalanceException;

	String insertCustomer(Customer customer);

	Customer login(long mobNo, String password);

	double showBalance(Customer customer);

	void printTransaction(long mobNo);

	String fundTransfer(Customer senderCustomer, Customer receiverCustomer, Double amount) throws SenderReceiverSameException, LowBalanceException,
	NegativeAmountException;

	Customer checkUser(long receiverMobNo);

	// declaring abstract methods
	
}
