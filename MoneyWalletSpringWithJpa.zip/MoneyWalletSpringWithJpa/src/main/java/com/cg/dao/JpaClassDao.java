package com.cg.dao;

import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.xml.bind.annotation.XmlTransient;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.ExceptionClass.LowBalanceException;
import com.cg.ExceptionClass.NegativeAmountException;
import com.cg.ExceptionClass.SenderReceiverSameException;
import com.cg.bean.Customer;
import com.cg.bean.Transaction;

@Transactional
@Repository("idao")
public class JpaClassDao implements InterfaceDao,ApplicationContextAware {

	@PersistenceContext(unitName = "JPA-PU")
	private EntityManager entityManager;
	ApplicationContext ctx;
	
//	@Autowired
	Transaction tran;

	public JpaClassDao() {
//		ctx = new ClassPathXmlApplicationContext("annotated.xml");
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public String deposit(Customer customer, double amount) throws NegativeAmountException {
		if (amount <= 0) {
			throw new NegativeAmountException("Please enter amount greater than 0");
		} else {
			customer.setBalance(customer.getBalance() + amount);
			entityManager.persist(customer);

			tran = (Transaction) ctx.getBean("transaction");
			tran.setType("credit");
			tran.setAmount(amount);
			tran.setBalance(customer.getBalance());
			tran.setMobNo(customer.getMobileNo());
			entityManager.persist(tran);

			return "Rs " + amount + " deposited successfully at " + LocalDateTime.now() + " for mobile no: "
					+ customer.getMobileNo() + "\n Your updated balance is: " + showBalance(customer);
		}
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public String withdraw(Customer customer, double amount) throws LowBalanceException {
		if (customer.getBalance() < amount) {
			throw new LowBalanceException("Your balance is low");
		} else {
			customer.setBalance(customer.getBalance() - amount);
			entityManager.persist(customer);

			tran = (Transaction) ctx.getBean("transaction");
			tran.setType("debit");
			tran.setAmount(amount);
			tran.setBalance(customer.getBalance());
			tran.setMobNo(customer.getMobileNo());
			entityManager.persist(tran);

			return "Rs " + amount + " withdrawn successfully at " + LocalDateTime.now() + " for mobile no: "
					+ customer.getMobileNo() + "\n Your updated balance is: " + showBalance(customer);
		}
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public String insertCustomer(Customer customer) {
		entityManager.persist(customer);
		return "Registration successfull! your username is your mobile number: "
				+ customer.getMobileNo();
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public Customer login(long mobNo, String password) {

		Customer customer = getCustomer(mobNo);
		if (customer != null) {
			return customer;
		} else {
			System.out.println("cust is null");
			return null;
		}
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public double showBalance(Customer customer) {
		Customer cust = getCustomer(customer.getMobileNo());
		return cust.getBalance();
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void printTransaction(long mobNo) {
		List<Transaction> list = entityManager
				.createQuery(
						"SELECT t from Transaction t where mobNo=:mobNo order by t.id",
						Transaction.class).setParameter("mobNo", mobNo)
				.getResultList();

		for (Transaction t : list) {
			System.out.println(t);
		}
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public String fundTransfer(Customer senderCustomer, Customer receiverCustomer, Double amount)
			throws SenderReceiverSameException, LowBalanceException, NegativeAmountException {
		if (senderCustomer.getMobileNo() == receiverCustomer.getMobileNo()) {

			throw new SenderReceiverSameException("Cannot send to yourself");

		} else {
			withdraw(senderCustomer, amount);
			deposit(receiverCustomer, amount);

			return amount + " Rs transferred to mobile number: "
					+ receiverCustomer.getMobileNo()
					+ "\n Your updated balance is: "
					+ showBalance(senderCustomer);
		}
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public Customer checkUser(long receiverMobNo) {
		Customer cust = getCustomer(receiverMobNo);
		return cust;
	}

	public void initDao(ApplicationContext ctx) {
		// TODO Auto-generated method stub

	}

	public Customer getCustomer(long custMobno) {
		return entityManager
				.createQuery(
						"SELECT c from Customer c WHERE c.mobileNo=:mobile",
						Customer.class)
				.setParameter("mobile", custMobno).getSingleResult();
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.ctx=applicationContext;
		
	}



}
